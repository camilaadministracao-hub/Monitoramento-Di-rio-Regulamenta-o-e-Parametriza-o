from __future__ import annotations

import json
import re
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

BR_TZ = timezone(timedelta(hours=-3))
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
HIST = DATA / "historico"
DATA.mkdir(exist_ok=True)
HIST.mkdir(exist_ok=True)

FONTES = [
    {"orgao": "ANS", "tipo": "Notícias", "url": "https://www.gov.br/ans/pt-br/assuntos/noticias"},
    {"orgao": "ANS", "tipo": "Legislação", "url": "https://www.gov.br/ans/pt-br/acesso-a-informacao/legislacao"},
    {"orgao": "ANVISA", "tipo": "Notícias", "url": "https://www.gov.br/anvisa/pt-br/assuntos/noticias-anvisa"},
    {"orgao": "Ministério da Saúde", "tipo": "Notícias", "url": "https://www.gov.br/saude/pt-br/assuntos/noticias"},
    {"orgao": "CONITEC", "tipo": "Notícias", "url": "https://www.gov.br/conitec/pt-br/assuntos/noticias"},
    {"orgao": "DOU", "tipo": "Consulta", "url": "https://www.in.gov.br/consulta"},
    {"orgao": "Planalto", "tipo": "Legislação", "url": "https://www4.planalto.gov.br/legislacao"},
    {"orgao": "Receita Federal", "tipo": "Notícias", "url": "https://www.gov.br/receitafederal/pt-br/assuntos/noticias"},
    {"orgao": "ANPD", "tipo": "Notícias", "url": "https://www.gov.br/anpd/pt-br/assuntos/noticias"},
    {"orgao": "INPI", "tipo": "Notícias", "url": "https://www.gov.br/inpi/pt-br/central-de-conteudo/noticias"},
]

PALAVRAS_CRITICAS = [
    "resolução", "instrução normativa", "portaria", "lei", "decreto", "consulta pública",
    "suspensão", "interdição", "recolhimento", "proibição", "sanitária", "registro", "prazo",
    "operadora", "ans", "anvisa", "cnes", "tiss", "rol", "rps", "dou", "alvará",
]

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; MonitoramentoRegulatorio/3.0; +https://github.com/)"
}


def prioridade(texto: str) -> str:
    t = texto.lower()
    muito_critico = ["suspensão", "interdição", "recolhimento", "proibição", "ação imediata"]
    legislativo = ["resolução", "instrução normativa", "portaria", "lei", "decreto", "dou"]
    if any(p in t for p in muito_critico):
        return "Ação imediata"
    if any(p in t for p in legislativo):
        return "Necessita avaliação"
    if any(p in t for p in PALAVRAS_CRITICAS):
        return "Atenção"
    return "Informativo"


def resumo(texto: str, limite: int = 230) -> str:
    texto = re.sub(r"\s+", " ", texto or "").strip()
    return texto if len(texto) <= limite else texto[: limite - 1].rstrip() + "…"


def extrair_itens(fonte: dict) -> tuple[list[dict], str | None]:
    url = fonte["url"]
    try:
        resp = requests.get(url, headers=HEADERS, timeout=25)
        resp.raise_for_status()
    except Exception as exc:
        return [], str(exc)

    soup = BeautifulSoup(resp.text, "html.parser")
    candidatos = []

    seletores = [
        "article a",
        ".tileItem a",
        ".summary a",
        "h2 a",
        "h3 a",
        "a",
    ]
    vistos = set()
    for seletor in seletores:
        for a in soup.select(seletor):
            titulo = resumo(a.get_text(" ", strip=True), 180)
            href = a.get("href")
            if not titulo or not href:
                continue
            if len(titulo) < 12:
                continue
            link = urljoin(url, href)
            chave = (titulo.lower(), link)
            if chave in vistos:
                continue
            vistos.add(chave)
            texto_contexto = resumo(a.parent.get_text(" ", strip=True) if a.parent else titulo)
            candidatos.append({
                "orgao": fonte["orgao"],
                "tipo": fonte["tipo"],
                "titulo": titulo,
                "resumo": texto_contexto or titulo,
                "link": link,
                "prioridade": prioridade(f"{titulo} {texto_contexto} {fonte['tipo']}"),
                "coletado_em": datetime.now(BR_TZ).isoformat(timespec="seconds"),
            })
            if len(candidatos) >= 12:
                break
        if len(candidatos) >= 6:
            break

    return candidatos[:10], None


def main() -> None:
    agora = datetime.now(BR_TZ)
    todos = []
    status_fontes = []

    for fonte in FONTES:
        itens, erro = extrair_itens(fonte)
        todos.extend(itens)
        status_fontes.append({
            "orgao": fonte["orgao"],
            "tipo": fonte["tipo"],
            "url": fonte["url"],
            "status": "erro" if erro else "ok",
            "erro": erro,
            "itens": len(itens),
        })

    total_alertas = sum(1 for i in todos if i["prioridade"] in ["Atenção", "Necessita avaliação", "Ação imediata"])
    resultado = {
        "executado_em": agora.strftime("%d/%m/%Y %H:%M"),
        "executado_em_iso": agora.isoformat(timespec="seconds"),
        "status": "concluido",
        "total_fontes": len(FONTES),
        "total_itens": len(todos),
        "total_alertas": total_alertas,
        "fontes_com_erro": sum(1 for f in status_fontes if f["status"] == "erro"),
        "itens": todos,
        "fontes": status_fontes,
    }

    (DATA / "resultado_atual.json").write_text(json.dumps(resultado, ensure_ascii=False, indent=2), encoding="utf-8")
    nome_hist = agora.strftime("%Y-%m-%d_%H-%M") + ".json"
    (HIST / nome_hist).write_text(json.dumps(resultado, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Monitoramento concluído: {len(todos)} itens, {total_alertas} alertas.")


if __name__ == "__main__":
    main()
